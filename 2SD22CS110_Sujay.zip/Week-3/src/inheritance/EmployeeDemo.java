package inheritance;

//Dynamic Method Dispatch
abstract class Person {
//	private String name;
//	private String mobile;
	protected String name;
	protected String mobile;

	Person(String name, String mobile) {
		this.name = name;
		this.mobile = mobile;
	}

//	void display() {
//		System.out.println("Name: " + name);
//		System.out.println("Mobile: " + mobile);
//	}
	abstract void display();
}

class Student extends Person {
	private String usn;
	private String branch;

	Student(String name, String mobile, String usn, String branch) {
		super(name, mobile);
		this.usn = usn;
		this.branch = branch;
	}

	void display() {
		//super.display();
		System.out.println("Name: " + name);
		System.out.println("Mobile: " + mobile);
		System.out.println("USN: " + usn);
		System.out.println("Branch: " + branch);
	}
}

class Employee extends Person {
	private String empID;
	private String department;

	Employee(String name, String mobile, String empID, String department) {
		super(name, mobile);
		this.empID = empID;
		this.department = department;
	}

	void display() {
//		super.display();
		System.out.println("Name: " + name);
		System.out.println("Mobile: " + mobile);
		System.out.println("Employee ID: " + empID);
		System.out.println("Department: " + department);
	}

}

public class EmployeeDemo {

	public static void main(String[] args) {
		Person p;
		p = new Student("Sujay", "5678", "2SD22CS110", "Computer Science and Engineering");
		p.display();
		System.out.print("\n");
		p = new Employee("Sujay", "0836", "abcd", "Administration");
		p.display();
	}

}
