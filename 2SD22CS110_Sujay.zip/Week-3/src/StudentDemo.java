//use private access specifier
//use of this keyword
//use of super() and super.
//use of method overriding
//use of parameterized constructors
class Person {
	private String name;
	private String mobile;

	Person(String name, String mobile) {
		this.name = name;
		this.mobile = mobile;
	}

	void display() {
		System.out.println("Name: " + name);
		System.out.println("Mobile: " + mobile);
	}
}

class Student extends Person {
	private String usn;
	private String branch;

	Student(String name, String mobile, String usn, String branch) {
		super(name, mobile);
		this.usn = usn;
		this.branch = branch;
	}

	void display() {
		super.display();
		System.out.println("USN: " + usn);
		System.out.println("Branch: " + branch);
	}
}

public class StudentDemo {

	public static void main(String[] args) {

		Person p = new Person("Sujay", "1234");
		p.display();
		System.out.print("\n");
		Student st = new Student("Sujay", "5678", "2SD22CS110", "Computer Science and Engineering");
		st.display();

	}

}
