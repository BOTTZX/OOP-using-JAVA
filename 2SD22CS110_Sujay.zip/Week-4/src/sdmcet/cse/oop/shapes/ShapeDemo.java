package sdmcet.cse.oop.shapes;

interface Shape {
	double computeArea();

	double computePerimeter();
}

class Circle implements Shape {
	private int radius;

	Circle(int radius) {
		this.radius = radius;
	}

	@Override
	public double computeArea() {
		return Math.PI * radius * radius;
	}

	@Override
	public double computePerimeter() {
		return Math.PI * 2 * radius;
	}

}

class Triangle implements Shape {
	private int a, b, c;

	Triangle(int a, int b, int c) {
		this.a = a;
		this.b = b;
		this.c = c;
	}

	@Override
	public double computeArea() {
		double s = (a + b + c) / 2;
		return Math.sqrt(s * (s - a) * (s - b) * (s - c));

	}

	@Override
	public double computePerimeter() {
		return a + b + c;
	}

}

class Rectangle implements Shape {

	private int length;
	private int breadth;

	Rectangle(int length, int breadth) {
		this.length = length;
		this.breadth = breadth;
	}

	@Override
	public double computeArea() {
		return length * breadth;
	}

	@Override
	public double computePerimeter() {
		return 2 * (length + breadth);
	}

}

public class ShapeDemo {

	public static void main(String[] args) {
		Shape s;
		

		s = new Circle(5);
		System.out.println("Area of Circle of radius is : "+s.computeArea());
		System.out.println("Perimeter of Circle of radius is : "+s.computePerimeter());
		
		System.out.print("\n");
		
		s = new Triangle(3, 4, 5);
		System.out.println("Area of Triangle of sides cm is : "+s.computeArea());
		System.out.println("Perimeter of Triangle of sides"+s.computePerimeter());
		
		System.out.print("\n");
		
		s = new Rectangle(6, 8);
		System.out.println("Area of Rectangle of length is: "+s.computeArea());
		System.out.println("Perimeter of Rectangle of length "+s.computePerimeter());
		
		
	}

}
