package sdmcet.cse.oop.employee;

import sdmcet.cse.oop.person.*;

public class Employee extends Person {

	private String empID;
	private String department;

	public Employee(String name, String mobile, String empID, String department) {
		super(name, mobile);
		this.empID = empID;
		this.department = department;
	}

	public void display() {

		super.display();
		System.out.println("Employee ID: " + empID);
		System.out.println("Department: " + department);
	}

}
