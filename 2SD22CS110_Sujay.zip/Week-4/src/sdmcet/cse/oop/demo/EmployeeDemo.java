package sdmcet.cse.oop.demo;

import sdmcet.cse.oop.person.*;
import sdmcet.cse.oop.student.*;

import sdmcet.cse.oop.employee.*;

public class EmployeeDemo {
	public static void main(String[] args) {
		Person p;

		p = new Student("Sujay", "123", "123", "CSE");
		p.display();

		System.out.print("\n");

		p = new Employee("SujayB", "321", "321", "CSE");
		p.display();

	}
}
