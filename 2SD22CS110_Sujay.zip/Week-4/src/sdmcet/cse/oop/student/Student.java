package sdmcet.cse.oop.student;

import sdmcet.cse.oop.person.*;

public class Student extends Person {
	private String usn;
	private String branch;

	public Student(String name, String mobile, String usn, String branch) {
		super(name, mobile);
		this.usn = usn;
		this.branch = branch;
	}

	public void display() {
		super.display();
		System.out.println("USN: " + usn);
		System.out.println("Branch: " + branch);
	}
}
