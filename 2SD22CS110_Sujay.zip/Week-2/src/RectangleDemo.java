class Rectangle {
	int length;
	int breadth;
	
	Rectangle(int side) {
		this.length = side;
		this.breadth = side;
		}
	
	Rectangle(int length, int breadth) {
		this.length = length;
		this.breadth = breadth;
		}
	
//	void read(int side) {
//		this.length = side;
//		this.breadth = side;
//	}
//	void read(int length, int breadth) {
//		this.length = length;
//		this.breadth = breadth;
//	}
	double findArea() {
		return length * breadth;
	}
}
public class RectangleDemo {

	public static void main(String[] args) {
		
		Rectangle r1 = new Rectangle(3,4);
		
//		r1.read(3, 4);
		double area = r1.findArea();
		System.out.println("Area of rectangle of length " + r1.length + "cm and breadth " +r1.breadth + "cm is: " + area + " square centimeters.");
		
		Rectangle r2 = new Rectangle(5);
		
//		r2.read(5);
		area=r2.findArea();
		System.out.println("Area of square of side " +r2.length + "cm is : " + area + " square centimeters.");

	}

}
