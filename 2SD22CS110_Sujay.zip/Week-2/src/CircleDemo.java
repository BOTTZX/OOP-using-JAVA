class Circle {
	
	int radius;
	
	void readRadius(int radius) {
		this.radius =radius;
	}
	
	double findArea() {
		return 3.142 * radius * radius;
	}
}
public class CircleDemo {

	public static void main(String[] args) {
		
		Circle c1 = new Circle();
//		c1.radius=6; //insecure access
		c1.readRadius(6);
		double area = c1.findArea();
		System.out.println("Area of circle of radius "+ c1.radius + " cm is : " + area + " square centimeter.");
		
//		Circle c2 = new Circle();
//		c2.radius=10;
//		area = c2.findArea();
//		System.out.println("Area of circle of radius "+ c2.radius + " cm is : " + area + " square centimeter.");
		
		
	}

}
