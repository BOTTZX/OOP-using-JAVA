package sdmcet.cse.oop.exception;
import java.util.Scanner;

public class ExceptionDemo {

	static int calculate(int a, int b) {
		int c = 0;
		// try {
		// c = a / b;
		c = a + b;
		// } catch (ArithmeticException ae) {
		// ae.printStackTrace();
		// }
		return c;
	}

	public static void main(String[] args) {
		int a = 1, b = 0, c = 0;
		c = ExceptionDemo.calculate(a, b);
		try {
			
			System.out.println("Result = " + c);
		} catch (ArithmeticException ae) {
			System.out.println(ae);
		} finally {
			System.out.println("Inside ae Finally");
		}
		System.out.println("Outside ae Finally");

		int arr[] = { 1, 2, 3, 4 };
		try {
			System.out.println("Arr[4]= " + arr[4]);
		} catch (ArrayIndexOutOfBoundsException aioobe) {
			aioobe.printStackTrace();
		} finally {
			System.out.println("Inside AIOOBE Finally");
		}
		System.out.println("Outside AIOOBE Finally");

		try {
			int arr2[] = new int[-5];
		} catch (NegativeArraySizeException nase) {
			nase.printStackTrace();
		} finally {
			System.out.println("Inside NASE Finally");
		}
		System.out.println("Outside NASE Finally");
		
		String str=null;
		try {
			System.out.println(str.length());
		} catch(NullPointerException npe) {
			System.out.println(npe);
		} finally {
			System.out.println("Inside NPE Finally");
		}
		System.out.println("Outside NPE Finally");
		
		Scanner input=new Scanner(System.in);
		System.out.println("Enter: ");
		int x=Integer.valueOf(input.nextLine());
		int y=Integer.valueOf(input.nextLine());
		input.close();
		
		System.out.println(x+y);
		
		
		

	}
}
