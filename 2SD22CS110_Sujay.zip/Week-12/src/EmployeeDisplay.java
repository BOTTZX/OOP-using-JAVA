import java.sql.*;

public class EmployeeDisplay {

	public static void main(String[] args) throws SQLException {
		final String driver="com.mysql.jdbc.Driver";
		final String url="jdbc:mysql://localhost/2sd22cs110";
		final String user="root";
		final String pwd="";
		
		try {
			//Step 1
			Class.forName(driver);
			
			//Step 2
			Connection conn=DriverManager.getConnection(url,user,pwd);
			if(conn!=null) {
				//Step 3
				Statement stmt=conn.createStatement();
				
				String sql="Select * from employee";
				
				ResultSet rs=stmt.executeQuery(sql);
				
				while(rs.next()) {
					System.out.println(rs.getInt(1)+" "+rs.getString(2)+" "+rs.getDouble(3));
				}
			}//end of if
			else {
				System.out.println("Connection failed.");
				System.exit(0);
			}//end of else
			conn.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}

}
